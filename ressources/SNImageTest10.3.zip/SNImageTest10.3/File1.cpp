#pragma hdrstop
#pragma argsused

#ifdef _WIN32
#include <tchar.h>
#else
  typedef char _TCHAR;
  #define _tmain main
#endif

#include <stdio.h>
#include "SNImage.h"
int _tmain(int argc, _TCHAR* argv[]) 
{   SNImage img;
	img.Charger("image.bmp");
    img.Sauvegarder("result.bmp");
	return 0;
}
